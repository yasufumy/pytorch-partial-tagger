from partial_tagger.encoders.base import BaseEncoder, BaseEncoderFactory  # NOQA
