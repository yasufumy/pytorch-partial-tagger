from partial_tagger.decoders.viterbi import ViterbiDecoder  # NOQA
