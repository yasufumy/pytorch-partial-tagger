from partial_tagger.data.core import (  # NOQA
    Alignment,
    LabelSet,
    Span,
    Tag,
)
